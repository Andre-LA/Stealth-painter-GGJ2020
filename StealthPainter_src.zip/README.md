Jogo criado na Global Game Jam 2020

Desenvolvedores:

* André Luiz Alvares: programação;
* Fabricio Vigneron: programação;
* Felipe Marinho de Carvalho: arte e design.
* Matheus: Desenho de nível e testes;
* Paulo Sergio Soares Junior: programação;
* Tauã Amaro Pereira: arte e design;
