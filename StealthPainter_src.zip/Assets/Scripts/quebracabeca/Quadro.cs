﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quadro : MonoBehaviour
{
    public int id;
    
    void Awake()
    {
        EstadoDeJogo.faseAtual = id;
    }
}
